from django.contrib import admin
from .models import Hall, Board

admin.site.register(Hall)
admin.site.register(Board)
